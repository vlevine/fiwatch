import java.nio.file.Path;

public interface FileStats {
	void process(Path file);
}
